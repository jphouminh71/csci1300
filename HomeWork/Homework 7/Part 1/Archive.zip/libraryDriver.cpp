#include <iostream>

using namespace std;

int main()
{
	// Put your algorithms here. We have provided an example below of loading from the external data files.
	//
	//
	// create new Library object which will have all users in an array and all books in an array 
	// Read the file books.txt 
		// open instreams and process the data
	// Read the file users.txt 
		// use getline function and split function
	// Check if file open fails for either file 
		// is the .fail operation or is_open
	//		if a file open fails, print "Error. User file or book file could not be found. Please make sure that users.txt and books.txt is in the same directory."
	//		exit program 
	// Create a book object for each book in the book file 
		// when processing the data pull of from the names to create the new objects
	// Create a user object for each user in the book file 
		// call the class overloaded constructor
	// present menu to the user
		// print statements followed by user input then have conditionals
	// the menu should have the following options: 
	//		quit
	//		view
	//		rate
	//		get recommendations
	// 		rate a book
			// this should all be done by have certain characters represent a value and a function should be called if the input is one of those characters
If it isn’t then inform the user
	//	Continue elaborating what should happen if the user selects other menu options. You should also think about what happens 
		// possibly set up a boolean and put it all in a while loop so that the
		// menu will keep asking the user for an input for as long as they don’t
		// input the correct type of value
		
	//	when the user provides invalid input, or some operation cannot occur.	
		// inform the user
			// return -1 or create a loop that will keep asking until they input the required type.  
	
	return 0;
}

// login
	// function would check if existing object name exists or not if it doesn’t then create a new object
	// if found present the menu
// quit 
	// exit program after values have been saved 

